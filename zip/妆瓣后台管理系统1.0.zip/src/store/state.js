export default {
  listTmp: [],
  moviesArr: [],
  openId: "",
  myWxInfo: {},
  myCosInfo: {},
	myLoginInfo: {}
}