<template>
	<div class="comment">
		评论信息
	</div>
</template>

<script>
	export default{
		name:'comment',
		
	}
</script>

<style scoped>
	.comment{
		padding: 10px;
		width: 80%;
		background-color:gainsboro ;
	}
</style>
